package cr.ac.fidelitas.gimnasio.repository;

import cr.ac.fidelitas.gimnasio.domain.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}
