package cr.ac.fidelitas.gimnasio.controllers;

import cr.ac.fidelitas.gimnasio.domain.Categoria;
import cr.ac.fidelitas.gimnasio.service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/categorias")
public class CategoriaController {

    @Autowired
    private CategoriaService categoriaService;

    @GetMapping
    public String listarCategorias(Model modelo) {
        modelo.addAttribute("categorias", categoriaService.listarCategorias());
        return "categorias/lista";
    }

    @GetMapping("/nueva")
    public String mostrarFormularioNuevaCategoria(Model modelo) {
        modelo.addAttribute("categoria", new Categoria());
        return "categorias/formulario";
    }

    @PostMapping("/guardar")
    public String guardarCategoria(@ModelAttribute("categoria") Categoria categoria) {
        categoriaService.guardarCategoria(categoria);
        return "redirect:/categorias";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditarCategoria(@PathVariable Integer id, Model modelo) {
        Categoria categoria = categoriaService.buscarCategoriaPorId(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada: " + id));
        modelo.addAttribute("categoria", categoria);
        return "categorias/formulario";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarCategoria(@PathVariable Integer id) {
        categoriaService.eliminarCategoria(id);
        return "redirect:/categorias";
    }
}
