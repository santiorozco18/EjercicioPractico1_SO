package cr.ac.fidelitas.gimnasio.service.impl;

import cr.ac.fidelitas.gimnasio.domain.Reserva;
import cr.ac.fidelitas.gimnasio.repository.ReservaRepository;
import cr.ac.fidelitas.gimnasio.service.ReservaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReservaServiceImpl implements ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;

    @Override
    public List<Reserva> listarReservas() {
        return reservaRepository.findAll();
    }

    @Override
    public Optional<Reserva> buscarReservaPorId(Integer id) {
        return reservaRepository.findById(id);
    }

    @Override
    public void guardarReserva(Reserva reserva) {
        reservaRepository.save(reserva);
    }

    @Override
    public void eliminarReserva(Integer id) {
        reservaRepository.deleteById(id);
    }
}
