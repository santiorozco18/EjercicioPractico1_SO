package cr.ac.fidelitas.gimnasio.service;

import cr.ac.fidelitas.gimnasio.domain.Reserva;
import java.util.List;
import java.util.Optional;

public interface ReservaService {

    List<Reserva> listarReservas();

    Optional<Reserva> buscarReservaPorId(Integer id);

    void guardarReserva(Reserva reserva);

    void eliminarReserva(Integer id);
}
