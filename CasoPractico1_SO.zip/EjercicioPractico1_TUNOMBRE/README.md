# FitZone Gym — Caso Práctico 1

Aplicación web para gestión de un gimnasio desarrollada con **Spring Boot + Thymeleaf + MySQL**.

## Requisitos previos
- Java 17+
- Maven
- MySQL 8+
- IDE (IntelliJ / Eclipse / VS Code)

## Configuración inicial

### 1. Base de datos
Ejecuta el script SQL en MySQL Workbench:
```
gimnasio_fitness.sql
```
Esto crea el usuario, la base de datos, las tablas y los datos de prueba.

### 2. Ejecutar la aplicación
```bash
mvn spring-boot:run
```

La aplicación corre en: **http://localhost:47**

## Estructura de paquetes
```
cr.ac.fidelitas.gimnasio
├── domain          → Entidades JPA (Categoria, Servicio, Reserva)
├── repository      → Interfaces JPA Repository
├── service         → Interfaces de servicio
│   └── impl        → Implementaciones de servicio
└── controllers     → Controladores Spring MVC
```

## Funcionalidades
| Módulo | Ruta | CRUD |
|--------|------|------|
| Inicio | `/` | Página promocional |
| Categorías | `/categorias` | Completo |
| Clases/Servicios | `/servicios` | Completo |
| Reservas | `/reservas` | Completo |
| Contacto | `/contacto` | Solo interfaz |

## Tecnologías
- Spring Boot 3.2.5
- Spring Data JPA
- Thymeleaf
- MySQL Driver
- Bootstrap 5.3
- Bootstrap Icons
