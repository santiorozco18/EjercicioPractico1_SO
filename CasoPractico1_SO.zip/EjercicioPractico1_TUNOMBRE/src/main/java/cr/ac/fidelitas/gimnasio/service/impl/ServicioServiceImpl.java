package cr.ac.fidelitas.gimnasio.service.impl;

import cr.ac.fidelitas.gimnasio.domain.Servicio;
import cr.ac.fidelitas.gimnasio.repository.ServicioRepository;
import cr.ac.fidelitas.gimnasio.service.ServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicioServiceImpl implements ServicioService {

    @Autowired
    private ServicioRepository servicioRepository;

    @Override
    public List<Servicio> listarServicios() {
        return servicioRepository.findAll();
    }

    @Override
    public Optional<Servicio> buscarServicioPorId(Integer id) {
        return servicioRepository.findById(id);
    }

    @Override
    public void guardarServicio(Servicio servicio) {
        servicioRepository.save(servicio);
    }

    @Override
    public void eliminarServicio(Integer id) {
        servicioRepository.deleteById(id);
    }
}
