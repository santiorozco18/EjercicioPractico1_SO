package cr.ac.fidelitas.gimnasio.repository;

import cr.ac.fidelitas.gimnasio.domain.Servicio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServicioRepository extends JpaRepository<Servicio, Integer> {
}
