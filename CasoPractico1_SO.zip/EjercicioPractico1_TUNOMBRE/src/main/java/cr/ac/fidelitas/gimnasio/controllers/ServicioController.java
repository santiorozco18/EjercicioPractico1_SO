package cr.ac.fidelitas.gimnasio.controllers;

import cr.ac.fidelitas.gimnasio.domain.Servicio;
import cr.ac.fidelitas.gimnasio.service.CategoriaService;
import cr.ac.fidelitas.gimnasio.service.ServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/servicios")
public class ServicioController {

    @Autowired
    private ServicioService servicioService;

    @Autowired
    private CategoriaService categoriaService;

    @GetMapping
    public String listarServicios(Model modelo) {
        modelo.addAttribute("servicios", servicioService.listarServicios());
        return "servicios/lista";
    }

    @GetMapping("/nuevo")
    public String mostrarFormularioNuevoServicio(Model modelo) {
        modelo.addAttribute("servicio", new Servicio());
        modelo.addAttribute("categorias", categoriaService.listarCategorias());
        return "servicios/formulario";
    }

    @PostMapping("/guardar")
    public String guardarServicio(@ModelAttribute("servicio") Servicio servicio) {
        servicioService.guardarServicio(servicio);
        return "redirect:/servicios";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditarServicio(@PathVariable Integer id, Model modelo) {
        Servicio servicio = servicioService.buscarServicioPorId(id)
                .orElseThrow(() -> new RuntimeException("Servicio no encontrado: " + id));
        modelo.addAttribute("servicio", servicio);
        modelo.addAttribute("categorias", categoriaService.listarCategorias());
        return "servicios/formulario";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarServicio(@PathVariable Integer id) {
        servicioService.eliminarServicio(id);
        return "redirect:/servicios";
    }
}
