package cr.ac.fidelitas.gimnasio.service;

import cr.ac.fidelitas.gimnasio.domain.Servicio;
import java.util.List;
import java.util.Optional;

public interface ServicioService {

    List<Servicio> listarServicios();

    Optional<Servicio> buscarServicioPorId(Integer id);

    void guardarServicio(Servicio servicio);

    void eliminarServicio(Integer id);
}
