package cr.ac.fidelitas.gimnasio.controllers;

import cr.ac.fidelitas.gimnasio.domain.Reserva;
import cr.ac.fidelitas.gimnasio.service.ReservaService;
import cr.ac.fidelitas.gimnasio.service.ServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reservas")
public class ReservaController {

    @Autowired
    private ReservaService reservaService;

    @Autowired
    private ServicioService servicioService;

    @GetMapping
    public String listarReservas(Model modelo) {
        modelo.addAttribute("reservas", reservaService.listarReservas());
        return "reservas/lista";
    }

    @GetMapping("/nueva")
    public String mostrarFormularioNuevaReserva(Model modelo) {
        modelo.addAttribute("reserva", new Reserva());
        modelo.addAttribute("servicios", servicioService.listarServicios());
        return "reservas/formulario";
    }

    @PostMapping("/guardar")
    public String guardarReserva(@ModelAttribute("reserva") Reserva reserva) {
        reservaService.guardarReserva(reserva);
        return "redirect:/reservas";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditarReserva(@PathVariable Integer id, Model modelo) {
        Reserva reserva = reservaService.buscarReservaPorId(id)
                .orElseThrow(() -> new RuntimeException("Reserva no encontrada: " + id));
        modelo.addAttribute("reserva", reserva);
        modelo.addAttribute("servicios", servicioService.listarServicios());
        return "reservas/formulario";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarReserva(@PathVariable Integer id) {
        reservaService.eliminarReserva(id);
        return "redirect:/reservas";
    }
}
