package cr.ac.fidelitas.gimnasio.service;

import cr.ac.fidelitas.gimnasio.domain.Categoria;
import java.util.List;
import java.util.Optional;

public interface CategoriaService {

    List<Categoria> listarCategorias();

    Optional<Categoria> buscarCategoriaPorId(Integer id);

    void guardarCategoria(Categoria categoria);

    void eliminarCategoria(Integer id);
}
