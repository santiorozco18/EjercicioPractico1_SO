package cr.ac.fidelitas.gimnasio.repository;

import cr.ac.fidelitas.gimnasio.domain.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva, Integer> {
}
